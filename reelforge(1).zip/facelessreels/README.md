# Reelforge — automated faceless video studio

A SaaS app that turns a niche into a daily short-form video, published
automatically to YouTube, Instagram, and TikTok. Built with Next.js 14 (App
Router), Supabase (auth + Postgres + storage), OpenAI (scripts + images),
ElevenLabs (voiceover), ffmpeg (render), and Stripe (billing).

## Architecture at a glance

```
Niche  →  Script (OpenAI)  →  Voiceover (ElevenLabs)  →  Images (DALL-E)
                                                              │
                                                              ▼
                                        Render worker (ffmpeg, separate process)
                                                              │
                                                              ▼
                                    schedule_items  →  publish/route.ts  →  YouTube / IG / TikTok
```

- **Next.js app** (`app/`) — auth, dashboard, and the API routes that call
  OpenAI/ElevenLabs and write to Supabase. Runs on Vercel or any Node host.
- **Render worker** (`worker/`) — a separate always-on process that does
  the ffmpeg work. Serverless functions can't reliably run ffmpeg jobs that
  take 30-90+ seconds, so this is intentionally a different deployment.
- **Two cron routes** (`app/api/cron/`) — one generates a video per active
  niche on schedule, the other publishes videos once they've finished
  rendering and their scheduled time has arrived.

## Setup

1. **Supabase**
   - Create a project at supabase.com.
   - Run `supabase/schema.sql` in the SQL editor.
   - Create a public Storage bucket named `media` (Storage → New bucket →
     toggle "Public"). This is where voiceovers, scene images, and final
     videos live.
   - Copy the project URL + anon key + service role key into `.env.local`.

2. **OpenAI** — put an API key with GPT-4o and DALL-E 3 access into
   `OPENAI_API_KEY`.

3. **ElevenLabs** — put an API key and a voice ID into `ELEVENLABS_API_KEY`
   / `ELEVENLABS_DEFAULT_VOICE_ID`. `lib/elevenlabs.ts` exports `listVoices()`
   if you want to build a voice picker.

4. **Stripe** — create two recurring Prices (Starter, Pro), a webhook
   endpoint pointed at `/api/stripe/webhook` listening for
   `checkout.session.completed` and `customer.subscription.*`, and drop the
   keys into `.env.local`.

5. **YouTube** — Google Cloud Console → new project → enable "YouTube Data
   API v3" → OAuth consent screen → OAuth client (Web application) →
   authorized redirect URI `{APP_URL}/api/oauth/youtube/callback`.

6. **Instagram** — developers.facebook.com → create an app → add the
   Instagram Graph API product → redirect URI
   `{APP_URL}/api/oauth/instagram/callback`. The connecting Instagram
   account must be a Business/Creator account linked to a Facebook Page.

7. **TikTok** — developers.tiktok.com → create an app → request the
   Content Posting API → redirect URI
   `{APP_URL}/api/oauth/tiktok/callback`. **Read the limitations section
   below before promising users public auto-posting.**

8. Install and run:
   ```
   npm install
   npm run dev        # the Next.js app
   npm run worker      # the render worker, in a second terminal/process
   ```

## What's genuinely production-ready here vs. what needs your attention

**Solid as-is:** auth, database schema + RLS, dashboard UI, script
generation, voiceover generation, image generation, Stripe billing flow,
OAuth token exchange for all three platforms, the render pipeline logic.

**Needs your input before going live:**
- **TikTok**: unaudited apps can only post as private ("only me"). Public
  posting requires TikTok's Content Posting API review, which isn't
  guaranteed and can take weeks. The code publishes with
  `privacy_level: "SELF_ONLY"` until you flip it post-approval.
- **Instagram**: requires `instagram_content_publish` permission, which
  goes through Meta App Review for use beyond your own test users.
- **Timezone accuracy**: the cron scheduler currently compares posting
  times in UTC rather than converting through each user's
  `profiles.timezone`. Fine for a single-timezone beta, worth fixing
  before multi-region users rely on exact posting times.
- **Subtitle timing**: estimated from word count (~150 wpm) rather than
  real speech timestamps — good enough to read, not frame-accurate. Swap
  in Whisper word-level timestamps for tighter sync (see `worker/README.md`).
- **Vercel Cron auth header**: confirm in current Vercel docs whether Cron
  automatically sends `Authorization: Bearer $CRON_SECRET` for you, or
  whether you need to configure that explicitly — this has changed across
  Vercel's cron releases.

## Directory guide

```
app/(auth)/            login, signup
app/dashboard/          overview, create, videos, schedule, connections, billing, settings
app/api/scripts/        OpenAI script generation
app/api/voiceover/      ElevenLabs voiceover generation
app/api/images/         DALL-E scene image generation
app/api/video/          queues rendering, polls status
app/api/oauth/          YouTube / Instagram / TikTok OAuth
app/api/publish/        dispatches a finished video to its platform
app/api/stripe/         checkout + webhook
app/api/cron/           daily niche → video generation, and due-publish dispatch
lib/                    typed API wrappers (openai, elevenlabs, stripe, social/*)
worker/                 the ffmpeg render process (separate deployment)
supabase/schema.sql     full DB schema + RLS policies
```
