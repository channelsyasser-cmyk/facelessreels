import Link from "next/link";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-6">
      <Link
        href="/"
        className="flex items-center gap-2 font-display font-semibold text-lg mb-10 tracking-tightest"
      >
        <span className="w-2 h-2 rounded-full bg-ember" />
        Reelforge
      </Link>
      <div className="w-full max-w-sm rounded-xl2 border border-surface-border bg-surface p-8">
        {children}
      </div>
    </main>
  );
}
