"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";

export default function SignupPage() {
  const router = useRouter();
  const supabase = createClient();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { emailRedirectTo: `${window.location.origin}/dashboard` },
    });
    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    setSent(true);
  }

  if (sent) {
    return (
      <div className="text-center">
        <h1 className="font-display text-2xl font-semibold mb-2">Check your inbox</h1>
        <p className="text-ink2 text-sm">
          We sent a confirmation link to <span className="text-white">{email}</span>. Click it
          to activate your account.
        </p>
      </div>
    );
  }

  return (
    <>
      <h1 className="font-display text-2xl font-semibold mb-1">Create your studio</h1>
      <p className="text-ink2 text-sm mb-6">One niche, one schedule, hands off from here.</p>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div>
          <label className="text-xs text-ink2 mb-1.5 block">Email</label>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full rounded-lg bg-ink-800 border border-surface-border px-3 py-2.5 text-sm outline-none focus:border-ember transition"
            placeholder="you@studio.com"
          />
        </div>
        <div>
          <label className="text-xs text-ink2 mb-1.5 block">Password</label>
          <input
            type="password"
            required
            minLength={8}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full rounded-lg bg-ink-800 border border-surface-border px-3 py-2.5 text-sm outline-none focus:border-ember transition"
            placeholder="At least 8 characters"
          />
        </div>

        {error && <p className="text-danger text-sm">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="mt-2 w-full rounded-lg bg-ember text-ink-900 font-medium py-2.5 hover:bg-ember-soft transition disabled:opacity-50"
        >
          {loading ? "Creating account…" : "Create account"}
        </button>
      </form>

      <p className="text-sm text-ink2 mt-6 text-center">
        Already have an account?{" "}
        <Link href="/login" className="text-ember hover:underline">
          Log in
        </Link>
      </p>
    </>
  );
}
