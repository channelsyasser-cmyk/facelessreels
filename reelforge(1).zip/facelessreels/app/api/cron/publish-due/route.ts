import { NextRequest, NextResponse } from "next/server";
import { createServiceSupabase } from "@/lib/supabase/server";

/**
 * Runs every few minutes (see vercel.json). Finds schedule_items that are
 * due (scheduled_for <= now), still pending, and whose video has a
 * finished render (status "ready"), then calls /api/publish for each.
 */
export async function GET(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const supabase = createServiceSupabase();

  const { data: dueItems } = await supabase
    .from("schedule_items")
    .select("id, videos(status)")
    .eq("status", "pending")
    .lte("scheduled_for", new Date().toISOString());

  const results: { id: string; ok: boolean }[] = [];

  for (const item of dueItems ?? []) {
    const video = item.videos as any;
    if (video?.status !== "ready") continue; // render not finished yet, try again next tick

    const res = await fetch(`${process.env.NEXT_PUBLIC_APP_URL}/api/publish`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.CRON_SECRET}`,
      },
      body: JSON.stringify({ scheduleItemId: item.id }),
    });
    results.push({ id: item.id, ok: res.ok });
  }

  return NextResponse.json({ processed: results.length, results });
}
