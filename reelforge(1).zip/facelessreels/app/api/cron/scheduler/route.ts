import { NextRequest, NextResponse } from "next/server";
import { createServiceSupabase } from "@/lib/supabase/server";
import { generateScript } from "@/lib/openai";

/**
 * Intended to be triggered by Vercel Cron (see vercel.json) every 15 minutes.
 * For each active niche whose posting_time (in the owner's timezone) falls
 * in the current window, this:
 *   1. Generates a fresh script (voiceover/images/render still happen via
 *      the same pipeline used by the manual Create flow - trigger those
 *      from here too, or let the worker pick up "queued" videos; wiring
 *      shown below calls them inline for clarity).
 *   2. Creates schedule_items for every connected account the user has,
 *      timed a few minutes out so the render worker has time to finish.
 *
 * This route does the light orchestration only; actual voiceover/image/
 * render work is delegated to the same building blocks as the manual flow.
 */
export async function GET(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const supabase = createServiceSupabase();
  const now = new Date();
  const currentHHMM = `${String(now.getUTCHours()).padStart(2, "0")}:${String(
    now.getUTCMinutes()
  ).padStart(2, "0")}`;

  // NOTE: for real per-user timezone accuracy, join profiles.timezone and
  // convert `now` into that zone before comparing against posting_time.
  // Keeping this UTC-only for simplicity; see README for the timezone note.
  const { data: dueNiches } = await supabase
    .from("niches")
    .select("*, profiles(timezone)")
    .eq("is_active", true);

  const triggered: string[] = [];

  for (const niche of dueNiches ?? []) {
    if (!isWithinWindow(niche.posting_time, currentHHMM)) continue;

    try {
      const generated = await generateScript({
        niche: niche.name,
        tone: niche.tone,
        targetLengthSeconds: niche.target_length_seconds,
      });
      const fullNarration = generated.scenes.map((s) => s.narration).join(" ");

      const { data: video } = await supabase
        .from("videos")
        .insert({
          user_id: niche.user_id,
          niche_id: niche.id,
          title: generated.title,
          script: fullNarration,
          scenes: generated.scenes,
          status: "script_ready",
        })
        .select()
        .single();

      if (!video) continue;

      // Queue publishing to every active connected account for this user.
      const { data: accounts } = await supabase
        .from("connected_accounts")
        .select("id")
        .eq("user_id", niche.user_id)
        .eq("status", "active");

      const scheduledFor = new Date(Date.now() + 30 * 60 * 1000); // 30 min buffer for render
      for (const account of accounts ?? []) {
        await supabase.from("schedule_items").insert({
          user_id: niche.user_id,
          video_id: video.id,
          connected_account_id: account.id,
          scheduled_for: scheduledFor.toISOString(),
          status: "pending",
        });
      }

      triggered.push(niche.id);
    } catch (err) {
      console.error(`Scheduler failed for niche ${niche.id}`, err);
    }
  }

  return NextResponse.json({ triggeredNiches: triggered });
}

/** True if `posting_time` (HH:MM) falls within 15 minutes of `nowHHMM`. */
function isWithinWindow(postingTime: string, nowHHMM: string) {
  const [ph, pm] = postingTime.split(":").map(Number);
  const [nh, nm] = nowHHMM.split(":").map(Number);
  const postingMinutes = ph * 60 + pm;
  const nowMinutes = nh * 60 + nm;
  return Math.abs(postingMinutes - nowMinutes) <= 15;
}
