import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase } from "@/lib/supabase/server";
import { generateSceneImage } from "@/lib/openai";

export async function POST(req: NextRequest) {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { videoId } = await req.json();
  if (!videoId) return NextResponse.json({ error: "Missing videoId" }, { status: 400 });

  const { data: video, error: fetchError } = await supabase
    .from("videos")
    .select("id, scenes, user_id")
    .eq("id", videoId)
    .eq("user_id", user.id)
    .single();

  if (fetchError || !video) {
    return NextResponse.json({ error: "Video not found" }, { status: 404 });
  }
  const scenes = (video.scenes as { narration: string; imagePrompt: string }[]) || [];
  if (scenes.length === 0) {
    return NextResponse.json({ error: "Video has no scenes yet" }, { status: 400 });
  }

  try {
    const uploadedUrls: string[] = [];
    const updatedScenes = [];

    for (let i = 0; i < scenes.length; i++) {
      const scene = scenes[i];
      const tempUrl = await generateSceneImage(scene.imagePrompt);

      // DALL-E URLs expire quickly - download and re-host in our own storage.
      const imgRes = await fetch(tempUrl);
      const imgBuffer = Buffer.from(await imgRes.arrayBuffer());
      const path = `${user.id}/${videoId}/scene-${i}.png`;

      const { error: uploadError } = await supabase.storage
        .from("media")
        .upload(path, imgBuffer, { contentType: "image/png", upsert: true });
      if (uploadError) throw uploadError;

      const { data: publicUrl } = supabase.storage.from("media").getPublicUrl(path);
      uploadedUrls.push(publicUrl.publicUrl);
      updatedScenes.push({ ...scene, imageUrl: publicUrl.publicUrl });
    }

    await supabase
      .from("videos")
      .update({ image_urls: uploadedUrls, scenes: updatedScenes, status: "images_ready" })
      .eq("id", videoId);

    return NextResponse.json({ imageUrls: uploadedUrls });
  } catch (err) {
    console.error(err);
    await supabase
      .from("videos")
      .update({
        status: "failed",
        error_message: err instanceof Error ? err.message : "Image generation failed",
      })
      .eq("id", videoId);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Image generation failed" },
      { status: 500 }
    );
  }
}
