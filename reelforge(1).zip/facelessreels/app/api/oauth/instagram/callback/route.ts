import { NextRequest, NextResponse } from "next/server";
import { createServiceSupabase } from "@/lib/supabase/server";
import { exchangeInstagramCode, getInstagramAccountId } from "@/lib/social/instagram";

export async function GET(req: NextRequest) {
  const code = req.nextUrl.searchParams.get("code");
  const userId = req.nextUrl.searchParams.get("state");
  if (!code || !userId) {
    return NextResponse.redirect(
      new URL("/dashboard/connections?error=missing_code", process.env.NEXT_PUBLIC_APP_URL!)
    );
  }

  try {
    const redirectUri = `${process.env.NEXT_PUBLIC_APP_URL}/api/oauth/instagram/callback`;
    const { access_token } = await exchangeInstagramCode(code, redirectUri);

    // The user must have a Facebook Page linked to their IG Business account.
    // We look up the first Page the token can manage, then resolve its IG account.
    const pagesRes = await fetch(
      `https://graph.facebook.com/v20.0/me/accounts?access_token=${access_token}`
    );
    const pagesData = await pagesRes.json();
    const page = pagesData.data?.[0];
    if (!page) throw new Error("No Facebook Page found for this account");

    const igUserId = await getInstagramAccountId(access_token, page.id);
    if (!igUserId) throw new Error("No Instagram Business account linked to that Page");

    const supabase = createServiceSupabase();
    await supabase.from("connected_accounts").upsert(
      {
        user_id: userId,
        platform: "instagram",
        platform_account_id: igUserId,
        display_name: page.name ?? "Instagram account",
        access_token,
        status: "active",
      },
      { onConflict: "user_id,platform,platform_account_id" }
    );

    return NextResponse.redirect(
      new URL("/dashboard/connections?connected=instagram", process.env.NEXT_PUBLIC_APP_URL!)
    );
  } catch (err) {
    console.error(err);
    return NextResponse.redirect(
      new URL("/dashboard/connections?error=instagram_failed", process.env.NEXT_PUBLIC_APP_URL!)
    );
  }
}
