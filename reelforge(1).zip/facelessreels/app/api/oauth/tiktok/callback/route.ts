import { NextRequest, NextResponse } from "next/server";
import { createServiceSupabase } from "@/lib/supabase/server";
import { exchangeTikTokCode } from "@/lib/social/tiktok";

export async function GET(req: NextRequest) {
  const code = req.nextUrl.searchParams.get("code");
  const userId = req.nextUrl.searchParams.get("state");
  if (!code || !userId) {
    return NextResponse.redirect(
      new URL("/dashboard/connections?error=missing_code", process.env.NEXT_PUBLIC_APP_URL!)
    );
  }

  try {
    const redirectUri = `${process.env.NEXT_PUBLIC_APP_URL}/api/oauth/tiktok/callback`;
    const tokens = await exchangeTikTokCode(code, redirectUri);

    const supabase = createServiceSupabase();
    await supabase.from("connected_accounts").upsert(
      {
        user_id: userId,
        platform: "tiktok",
        platform_account_id: tokens.open_id,
        display_name: "TikTok account",
        access_token: tokens.access_token,
        refresh_token: tokens.refresh_token,
        token_expires_at: new Date(Date.now() + tokens.expires_in * 1000).toISOString(),
        status: "active",
      },
      { onConflict: "user_id,platform,platform_account_id" }
    );

    return NextResponse.redirect(
      new URL("/dashboard/connections?connected=tiktok", process.env.NEXT_PUBLIC_APP_URL!)
    );
  } catch (err) {
    console.error(err);
    return NextResponse.redirect(
      new URL("/dashboard/connections?error=tiktok_failed", process.env.NEXT_PUBLIC_APP_URL!)
    );
  }
}
