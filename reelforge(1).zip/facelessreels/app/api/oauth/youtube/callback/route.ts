import { NextRequest, NextResponse } from "next/server";
import { createServiceSupabase } from "@/lib/supabase/server";
import { exchangeYouTubeCode } from "@/lib/social/youtube";

export async function GET(req: NextRequest) {
  const code = req.nextUrl.searchParams.get("code");
  const userId = req.nextUrl.searchParams.get("state");
  if (!code || !userId) {
    return NextResponse.redirect(
      new URL("/dashboard/connections?error=missing_code", process.env.NEXT_PUBLIC_APP_URL!)
    );
  }

  try {
    const redirectUri = `${process.env.NEXT_PUBLIC_APP_URL}/api/oauth/youtube/callback`;
    const tokens = await exchangeYouTubeCode(code, redirectUri);

    // Fetch the channel to store a friendly display name / channel id.
    const channelRes = await fetch(
      "https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true",
      { headers: { Authorization: `Bearer ${tokens.access_token}` } }
    );
    const channelData = await channelRes.json();
    const channel = channelData.items?.[0];

    const supabase = createServiceSupabase();
    await supabase.from("connected_accounts").upsert(
      {
        user_id: userId,
        platform: "youtube",
        platform_account_id: channel?.id ?? "unknown",
        display_name: channel?.snippet?.title ?? "YouTube channel",
        access_token: tokens.access_token,
        refresh_token: tokens.refresh_token,
        token_expires_at: new Date(Date.now() + tokens.expires_in * 1000).toISOString(),
        status: "active",
      },
      { onConflict: "user_id,platform,platform_account_id" }
    );

    return NextResponse.redirect(
      new URL("/dashboard/connections?connected=youtube", process.env.NEXT_PUBLIC_APP_URL!)
    );
  } catch (err) {
    console.error(err);
    return NextResponse.redirect(
      new URL("/dashboard/connections?error=youtube_failed", process.env.NEXT_PUBLIC_APP_URL!)
    );
  }
}
