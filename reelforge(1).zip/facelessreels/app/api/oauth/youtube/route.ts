import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase } from "@/lib/supabase/server";
import { getYouTubeAuthUrl } from "@/lib/social/youtube";

export async function GET(req: NextRequest) {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.redirect(new URL("/login", req.url));

  const redirectUri = `${process.env.NEXT_PUBLIC_APP_URL}/api/oauth/youtube/callback`;
  // `state` carries the user id through the redirect so the callback knows
  // who to attach the connected account to. In production, sign/encrypt this.
  const authUrl = getYouTubeAuthUrl(redirectUri, user.id);

  return NextResponse.redirect(authUrl);
}
