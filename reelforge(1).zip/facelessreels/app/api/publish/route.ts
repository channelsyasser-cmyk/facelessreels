import { NextRequest, NextResponse } from "next/server";
import { createServiceSupabase } from "@/lib/supabase/server";
import { uploadYouTubeShort, refreshYouTubeToken } from "@/lib/social/youtube";
import { publishInstagramReel } from "@/lib/social/instagram";
import { publishTikTokVideo } from "@/lib/social/tiktok";

/**
 * Publishes one schedule_items row. Called by the cron scheduler for
 * automatic daily publishing, or directly for a manual "publish now".
 * Uses the service-role client because this runs outside a user session
 * (triggered by cron, not by a logged-in request).
 */
export async function POST(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { scheduleItemId } = await req.json();
  const supabase = createServiceSupabase();

  const { data: item, error } = await supabase
    .from("schedule_items")
    .select("*, videos(*), connected_accounts(*)")
    .eq("id", scheduleItemId)
    .single();

  if (error || !item) return NextResponse.json({ error: "Schedule item not found" }, { status: 404 });

  const video = item.videos as any;
  const account = item.connected_accounts as any;

  if (!video?.video_url) {
    return NextResponse.json({ error: "Video has not finished rendering" }, { status: 400 });
  }

  await supabase
    .from("schedule_items")
    .update({ status: "publishing", attempts: item.attempts + 1 })
    .eq("id", scheduleItemId);

  try {
    let platformPostId: string;

    if (account.platform === "youtube") {
      let accessToken = account.access_token;
      // Refresh if the token is close to expiry.
      if (new Date(account.token_expires_at) < new Date(Date.now() + 60_000)) {
        const refreshed = await refreshYouTubeToken(account.refresh_token);
        accessToken = refreshed.access_token;
        await supabase
          .from("connected_accounts")
          .update({
            access_token: accessToken,
            token_expires_at: new Date(Date.now() + refreshed.expires_in * 1000).toISOString(),
          })
          .eq("id", account.id);
      }
      const videoRes = await fetch(video.video_url);
      const videoBuffer = Buffer.from(await videoRes.arrayBuffer());
      const result = await uploadYouTubeShort({
        accessToken,
        title: video.title ?? "Daily short",
        description: video.script?.slice(0, 400) ?? "",
        videoBuffer,
      });
      platformPostId = result.videoId;
    } else if (account.platform === "instagram") {
      const result = await publishInstagramReel({
        igUserId: account.platform_account_id,
        accessToken: account.access_token,
        videoUrl: video.video_url,
        caption: video.title ?? "",
      });
      platformPostId = result.mediaId;
    } else if (account.platform === "tiktok") {
      const result = await publishTikTokVideo({
        accessToken: account.access_token,
        videoUrl: video.video_url,
        caption: video.title ?? "",
      });
      platformPostId = result.publishId;
    } else {
      throw new Error(`Unknown platform: ${account.platform}`);
    }

    await supabase
      .from("schedule_items")
      .update({ status: "published", platform_post_id: platformPostId })
      .eq("id", scheduleItemId);
    await supabase.from("videos").update({ status: "published" }).eq("id", video.id);

    return NextResponse.json({ status: "published", platformPostId });
  } catch (err) {
    console.error(err);
    const message = err instanceof Error ? err.message : "Publish failed";
    await supabase
      .from("schedule_items")
      .update({ status: "failed", last_error: message })
      .eq("id", scheduleItemId);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
