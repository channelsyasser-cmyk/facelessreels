import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase } from "@/lib/supabase/server";
import { generateScript } from "@/lib/openai";

export async function POST(req: NextRequest) {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { niche, tone, targetLengthSeconds, nicheId } = await req.json();
  if (!niche) return NextResponse.json({ error: "Missing niche" }, { status: 400 });

  try {
    const generated = await generateScript({
      niche,
      tone: tone || "engaging, punchy, short sentences",
      targetLengthSeconds: targetLengthSeconds || 45,
    });

    const fullNarration = generated.scenes.map((s) => s.narration).join(" ");

    const { data: video, error } = await supabase
      .from("videos")
      .insert({
        user_id: user.id,
        niche_id: nicheId ?? null,
        title: generated.title,
        script: fullNarration,
        scenes: generated.scenes,
        status: "script_ready",
      })
      .select()
      .single();

    if (error) throw error;

    return NextResponse.json({
      videoId: video.id,
      script: fullNarration,
      scenes: generated.scenes,
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Script generation failed" },
      { status: 500 }
    );
  }
}
