import { NextRequest, NextResponse } from "next/server";
import { stripe } from "@/lib/stripe";
import { createServiceSupabase } from "@/lib/supabase/server";
import type Stripe from "stripe";

// Stripe webhooks need the raw body for signature verification, so this
// route must NOT be run through any body-parsing middleware.
export async function POST(req: NextRequest) {
  const body = await req.text();
  const signature = req.headers.get("stripe-signature");

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature!,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err) {
    console.error("Stripe webhook signature verification failed", err);
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  const supabase = createServiceSupabase();

  switch (event.type) {
    case "checkout.session.completed": {
      const session = event.data.object as Stripe.Checkout.Session;
      const userId = session.metadata?.supabase_user_id;
      const plan = session.metadata?.plan;
      if (userId && plan) {
        await supabase
          .from("profiles")
          .update({
            plan,
            stripe_subscription_id: session.subscription as string,
            subscription_status: "active",
          })
          .eq("id", userId);
      }
      break;
    }

    case "customer.subscription.updated":
    case "customer.subscription.deleted": {
      const subscription = event.data.object as Stripe.Subscription;
      const { data: profile } = await supabase
        .from("profiles")
        .select("id")
        .eq("stripe_customer_id", subscription.customer as string)
        .single();

      if (profile) {
        const isActive = subscription.status === "active";
        await supabase
          .from("profiles")
          .update({
            subscription_status: subscription.status,
            plan: isActive ? undefined : "free", // keep existing plan name if active; downgrade if not
          })
          .eq("id", profile.id);
      }
      break;
    }

    default:
      break;
  }

  return NextResponse.json({ received: true });
}
