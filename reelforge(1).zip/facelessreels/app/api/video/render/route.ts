import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase } from "@/lib/supabase/server";

/**
 * This route does NOT render the video itself. Rendering needs ffmpeg and
 * real wall-clock time (assembling images + audio + burned-in subtitles),
 * which doesn't fit inside a serverless function's time limit. Instead it
 * just flips the row to "rendering" - the worker in /worker polls for rows
 * in that state, does the ffmpeg work, uploads the mp4, and flips status to
 * "ready". Run the worker as a long-lived process (Railway, Render, Fly.io,
 * a small VPS) with `npm run worker`.
 */
export async function POST(req: NextRequest) {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { videoId } = await req.json();
  if (!videoId) return NextResponse.json({ error: "Missing videoId" }, { status: 400 });

  const { data: video, error } = await supabase
    .from("videos")
    .select("id, voiceover_url, image_urls, status")
    .eq("id", videoId)
    .eq("user_id", user.id)
    .single();

  if (error || !video) return NextResponse.json({ error: "Video not found" }, { status: 404 });
  if (!video.voiceover_url || !video.image_urls?.length) {
    return NextResponse.json(
      { error: "Video is missing voiceover or images - run those steps first" },
      { status: 400 }
    );
  }

  await supabase.from("videos").update({ status: "rendering" }).eq("id", videoId);

  return NextResponse.json({ status: "rendering" });
}
