import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase } from "@/lib/supabase/server";

export async function GET(req: NextRequest) {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const videoId = req.nextUrl.searchParams.get("videoId");
  if (!videoId) return NextResponse.json({ error: "Missing videoId" }, { status: 400 });

  const { data: video, error } = await supabase
    .from("videos")
    .select("id, status, video_url, error_message")
    .eq("id", videoId)
    .eq("user_id", user.id)
    .single();

  if (error || !video) return NextResponse.json({ error: "Video not found" }, { status: 404 });
  return NextResponse.json(video);
}
