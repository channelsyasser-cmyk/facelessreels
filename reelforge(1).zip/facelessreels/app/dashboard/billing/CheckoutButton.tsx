"use client";

import { useState } from "react";

export function CheckoutButton({
  planId,
  disabled,
}: {
  planId: "starter" | "pro";
  disabled?: boolean;
}) {
  const [loading, setLoading] = useState(false);

  async function handleClick() {
    setLoading(true);
    const res = await fetch("/api/stripe/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ planId }),
    });
    const { url } = await res.json();
    if (url) window.location.href = url;
    setLoading(false);
  }

  return (
    <button
      onClick={handleClick}
      disabled={disabled || loading}
      className="w-full rounded-full bg-ember text-ink-900 font-medium py-2.5 hover:bg-ember-soft transition disabled:opacity-40 disabled:cursor-not-allowed"
    >
      {disabled ? "Current plan" : loading ? "Redirecting…" : "Choose plan"}
    </button>
  );
}
