import { createServerSupabase } from "@/lib/supabase/server";
import { TopBar } from "@/components/TopBar";
import { CheckoutButton } from "./CheckoutButton";
import { Check } from "lucide-react";

const PLANS = [
  {
    id: "starter" as const,
    name: "Starter",
    price: "$29/mo",
    features: ["1 active niche", "1 video/day", "1 connected platform", "720p renders"],
  },
  {
    id: "pro" as const,
    name: "Pro",
    price: "$79/mo",
    features: [
      "5 active niches",
      "Up to 5 videos/day",
      "All 3 platforms",
      "1080p renders",
      "Priority render queue",
    ],
  },
];

export default async function BillingPage() {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: profile } = await supabase
    .from("profiles")
    .select("plan, subscription_status")
    .eq("id", user?.id)
    .single();

  return (
    <>
      <TopBar title="Billing" />
      <div className="p-8 max-w-3xl">
        <p className="text-ink2 text-sm mb-6">
          Current plan:{" "}
          <span className="text-white font-medium capitalize">{profile?.plan ?? "free"}</span>
          {profile?.subscription_status && profile.subscription_status !== "inactive" && (
            <span className="text-ink2"> ({profile.subscription_status})</span>
          )}
        </p>

        <div className="grid md:grid-cols-2 gap-4">
          {PLANS.map((plan) => (
            <div key={plan.id} className="rounded-xl2 border border-surface-border bg-surface p-6">
              <p className="text-xs uppercase tracking-widest text-ink2 mb-2">{plan.name}</p>
              <p className="font-display text-3xl font-semibold tracking-tightest mb-4">
                {plan.price}
              </p>
              <ul className="flex flex-col gap-2 mb-6">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-sm text-ink2">
                    <Check size={14} className="text-ember" /> {f}
                  </li>
                ))}
              </ul>
              <CheckoutButton planId={plan.id} disabled={profile?.plan === plan.id} />
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
