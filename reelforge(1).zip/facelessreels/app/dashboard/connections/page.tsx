import { createServerSupabase } from "@/lib/supabase/server";
import { TopBar } from "@/components/TopBar";
import { ConnectAccountCard } from "@/components/ConnectAccountCard";
import type { ConnectedAccount } from "@/lib/types";

export default async function ConnectionsPage() {
  const supabase = createServerSupabase();
  const { data: accounts } = await supabase.from("connected_accounts").select("*");

  const byPlatform = (platform: string) =>
    (accounts as ConnectedAccount[] | null)?.find((a) => a.platform === platform);

  return (
    <>
      <TopBar title="Connections" />
      <div className="p-8 max-w-2xl">
        <p className="text-ink2 text-sm mb-6">
          Connect the accounts you want Reelforge to publish to. Each platform requires you to
          approve access once — after that, publishing runs on its own.
        </p>
        <div className="flex flex-col gap-3">
          <ConnectAccountCard platform="youtube" account={byPlatform("youtube")} />
          <ConnectAccountCard platform="instagram" account={byPlatform("instagram")} />
          <ConnectAccountCard platform="tiktok" account={byPlatform("tiktok")} />
        </div>

        <div className="mt-8 rounded-xl2 border border-amberwarn/30 bg-amberwarn/5 p-4 text-sm text-amberwarn">
          TikTok posts land as private ("only me") until your TikTok developer app passes
          Content Posting API review. Everything else works the same either way.
        </div>
      </div>
    </>
  );
}
