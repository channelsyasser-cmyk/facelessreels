"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { TopBar } from "@/components/TopBar";
import { PipelineStepper } from "@/components/PipelineStepper";
import type { VideoStatus } from "@/lib/types";
import { Loader2, Wand2 } from "lucide-react";

export default function CreatePage() {
  const supabase = createClient();

  const [niche, setNiche] = useState("");
  const [tone, setTone] = useState("engaging, punchy, short sentences");
  const [length, setLength] = useState(45);

  const [status, setStatus] = useState<VideoStatus>("queued");
  const [busy, setBusy] = useState(false);
  const [videoId, setVideoId] = useState<string | null>(null);
  const [script, setScript] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function runPipeline() {
    setBusy(true);
    setError(null);
    try {
      // 1. Create the video row + generate the script
      setStatus("queued");
      const scriptRes = await fetch("/api/scripts/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ niche, tone, targetLengthSeconds: length }),
      });
      if (!scriptRes.ok) throw new Error(await scriptRes.text());
      const { videoId: id, script: generatedScript } = await scriptRes.json();
      setVideoId(id);
      setScript(generatedScript);
      setStatus("script_ready");

      // 2. Voiceover
      const voiceRes = await fetch("/api/voiceover/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ videoId: id }),
      });
      if (!voiceRes.ok) throw new Error(await voiceRes.text());
      setStatus("voice_ready");

      // 3. Images
      const imagesRes = await fetch("/api/images/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ videoId: id }),
      });
      if (!imagesRes.ok) throw new Error(await imagesRes.text());
      setStatus("images_ready");

      // 4. Kick off render (queues a job the worker picks up)
      const renderRes = await fetch("/api/video/render", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ videoId: id }),
      });
      if (!renderRes.ok) throw new Error(await renderRes.text());
      setStatus("rendering");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
      setStatus("failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <TopBar title="Create" />
      <div className="p-8 max-w-3xl">
        <div className="rounded-xl2 border border-surface-border bg-surface p-6 mb-6">
          <h2 className="font-display font-semibold mb-1">Feed the pipeline a niche</h2>
          <p className="text-ink2 text-sm mb-6">
            One run generates a script, voiceover, and matching visuals, then queues the
            render. Save this niche on the Schedule page to repeat it automatically.
          </p>

          <div className="flex flex-col gap-4">
            <div>
              <label className="text-xs text-ink2 mb-1.5 block">Niche</label>
              <input
                value={niche}
                onChange={(e) => setNiche(e.target.value)}
                placeholder="e.g. Stoic philosophy for entrepreneurs"
                className="w-full rounded-lg bg-ink-800 border border-surface-border px-3 py-2.5 text-sm outline-none focus:border-ember transition"
              />
            </div>
            <div>
              <label className="text-xs text-ink2 mb-1.5 block">Tone</label>
              <input
                value={tone}
                onChange={(e) => setTone(e.target.value)}
                className="w-full rounded-lg bg-ink-800 border border-surface-border px-3 py-2.5 text-sm outline-none focus:border-ember transition"
              />
            </div>
            <div>
              <label className="text-xs text-ink2 mb-1.5 block">
                Target length: {length}s
              </label>
              <input
                type="range"
                min={20}
                max={90}
                step={5}
                value={length}
                onChange={(e) => setLength(Number(e.target.value))}
                className="w-full accent-ember"
              />
            </div>

            <button
              onClick={runPipeline}
              disabled={busy || !niche.trim()}
              className="mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-ember text-ink-900 font-medium py-2.5 hover:bg-ember-soft transition disabled:opacity-50"
            >
              {busy ? <Loader2 size={16} className="animate-spin" /> : <Wand2 size={16} />}
              {busy ? "Running pipeline…" : "Generate video"}
            </button>
          </div>
        </div>

        {videoId && (
          <div className="rounded-xl2 border border-surface-border bg-surface p-6">
            <p className="text-xs uppercase tracking-widest text-ink2 mb-4">Pipeline status</p>
            <PipelineStepper status={status} />

            {script && (
              <div className="mt-6">
                <p className="text-xs uppercase tracking-widest text-ink2 mb-2">
                  Generated script
                </p>
                <p className="text-sm text-ink2 leading-relaxed whitespace-pre-line">
                  {script}
                </p>
              </div>
            )}

            {status === "rendering" && (
              <p className="text-xs text-ink2 mt-4">
                Rendering runs on the background worker — check the Videos tab in a minute for
                the finished file.
              </p>
            )}
          </div>
        )}

        {error && (
          <div className="mt-4 rounded-xl2 border border-danger/40 bg-danger/10 p-4 text-sm text-danger">
            {error}
          </div>
        )}
      </div>
    </>
  );
}
