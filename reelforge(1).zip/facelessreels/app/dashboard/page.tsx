import { Eye, Heart, Film, CalendarClock } from "lucide-react";
import { createServerSupabase } from "@/lib/supabase/server";
import { TopBar } from "@/components/TopBar";
import { StatCard } from "@/components/StatCard";
import { VideoCard } from "@/components/VideoCard";
import type { VideoRecord } from "@/lib/types";

export default async function DashboardOverview() {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();

  const { data: videos } = await supabase
    .from("videos")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(6);

  const { data: analyticsRows } = await supabase
    .from("video_analytics")
    .select("views, likes, schedule_item_id");

  const totalViews = (analyticsRows ?? []).reduce((sum, r) => sum + (r.views ?? 0), 0);
  const totalLikes = (analyticsRows ?? []).reduce((sum, r) => sum + (r.likes ?? 0), 0);

  const { count: publishedCount } = await supabase
    .from("videos")
    .select("*", { count: "exact", head: true })
    .eq("status", "published");

  const { count: scheduledCount } = await supabase
    .from("schedule_items")
    .select("*", { count: "exact", head: true })
    .eq("status", "pending");

  return (
    <>
      <TopBar title="Overview" email={user?.email} />
      <div className="p-8 max-w-6xl">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <StatCard label="Total views" value={totalViews.toLocaleString()} icon={Eye} />
          <StatCard label="Total likes" value={totalLikes.toLocaleString()} icon={Heart} />
          <StatCard label="Published" value={String(publishedCount ?? 0)} icon={Film} />
          <StatCard
            label="Scheduled"
            value={String(scheduledCount ?? 0)}
            icon={CalendarClock}
          />
        </div>

        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display font-semibold text-lg tracking-tightest">
            Recent videos
          </h2>
          <a href="/dashboard/videos" className="text-sm text-ember hover:underline">
            View all
          </a>
        </div>

        {videos && videos.length > 0 ? (
          <div className="flex flex-col gap-3">
            {(videos as VideoRecord[]).map((v) => (
              <VideoCard key={v.id} video={v} />
            ))}
          </div>
        ) : (
          <div className="rounded-xl2 border border-dashed border-surface-border p-10 text-center">
            <p className="text-ink2 text-sm mb-4">
              Nothing generated yet. Set a niche and let the pipeline run.
            </p>
            <a
              href="/dashboard/create"
              className="inline-flex px-4 py-2 rounded-full bg-ember text-ink-900 text-sm font-medium hover:bg-ember-soft transition"
            >
              Create your first video
            </a>
          </div>
        )}
      </div>
    </>
  );
}
