"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import type { Niche } from "@/lib/types";

export function NicheForm({ existingNiches }: { existingNiches: Niche[] }) {
  const router = useRouter();
  const supabase = createClient();
  const [name, setName] = useState("");
  const [postingTime, setPostingTime] = useState("09:00");
  const [saving, setSaving] = useState(false);

  async function addNiche(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    await supabase.from("niches").insert({
      user_id: user.id,
      name,
      posting_time: postingTime,
      is_active: true,
    });
    setName("");
    setSaving(false);
    router.refresh();
  }

  async function toggleNiche(id: string, isActive: boolean) {
    await supabase.from("niches").update({ is_active: !isActive }).eq("id", id);
    router.refresh();
  }

  return (
    <div className="flex flex-col gap-3">
      {existingNiches.map((niche) => (
        <div
          key={niche.id}
          className="rounded-xl2 border border-surface-border bg-surface px-5 py-3 flex items-center justify-between"
        >
          <div>
            <p className="text-sm font-medium">{niche.name}</p>
            <p className="text-xs text-ink2 font-mono">Daily at {niche.posting_time}</p>
          </div>
          <button
            onClick={() => toggleNiche(niche.id, niche.is_active)}
            className={`text-xs px-3 py-1.5 rounded-full transition ${
              niche.is_active
                ? "bg-mint/15 text-mint"
                : "bg-ink-800 text-ink2 border border-surface-border"
            }`}
          >
            {niche.is_active ? "Active" : "Paused"}
          </button>
        </div>
      ))}

      <form
        onSubmit={addNiche}
        className="rounded-xl2 border border-dashed border-surface-border p-4 flex gap-3 items-end"
      >
        <div className="flex-1">
          <label className="text-xs text-ink2 mb-1.5 block">New niche</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            placeholder="e.g. Daily productivity tips"
            className="w-full rounded-lg bg-ink-800 border border-surface-border px-3 py-2 text-sm outline-none focus:border-ember transition"
          />
        </div>
        <div>
          <label className="text-xs text-ink2 mb-1.5 block">Posting time</label>
          <input
            type="time"
            value={postingTime}
            onChange={(e) => setPostingTime(e.target.value)}
            className="rounded-lg bg-ink-800 border border-surface-border px-3 py-2 text-sm outline-none focus:border-ember transition"
          />
        </div>
        <button
          type="submit"
          disabled={saving}
          className="px-4 py-2 rounded-full bg-ember text-ink-900 text-sm font-medium hover:bg-ember-soft transition disabled:opacity-50"
        >
          Add
        </button>
      </form>
    </div>
  );
}
