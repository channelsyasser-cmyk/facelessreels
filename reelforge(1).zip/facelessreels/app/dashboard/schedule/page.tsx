import { createServerSupabase } from "@/lib/supabase/server";
import { TopBar } from "@/components/TopBar";
import { format } from "date-fns";
import { NicheForm } from "./NicheForm";

export default async function SchedulePage() {
  const supabase = createServerSupabase();

  const { data: niches } = await supabase
    .from("niches")
    .select("*")
    .order("created_at", { ascending: false });

  const { data: upcoming } = await supabase
    .from("schedule_items")
    .select("id, scheduled_for, status, videos(title), connected_accounts(platform, display_name)")
    .in("status", ["pending", "publishing"])
    .order("scheduled_for", { ascending: true })
    .limit(10);

  return (
    <>
      <TopBar title="Schedule" />
      <div className="p-8 max-w-4xl grid gap-8">
        <section>
          <h2 className="font-display font-semibold mb-1">Daily niches</h2>
          <p className="text-ink2 text-sm mb-4">
            Every active niche below gets a fresh video generated and queued for publish once
            per day at its posting time, via the daily cron job.
          </p>
          <NicheForm existingNiches={niches ?? []} />
        </section>

        <section>
          <h2 className="font-display font-semibold mb-3">Upcoming publishes</h2>
          {upcoming && upcoming.length > 0 ? (
            <div className="rounded-xl2 border border-surface-border bg-surface divide-y divide-surface-border">
              {upcoming.map((item: any) => (
                <div key={item.id} className="flex items-center justify-between px-5 py-3">
                  <div>
                    <p className="text-sm font-medium">{item.videos?.title ?? "Untitled"}</p>
                    <p className="text-xs text-ink2">
                      {item.connected_accounts?.platform} ·{" "}
                      {item.connected_accounts?.display_name}
                    </p>
                  </div>
                  <span className="text-xs font-mono text-ink2">
                    {format(new Date(item.scheduled_for), "MMM d, HH:mm")}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="rounded-xl2 border border-dashed border-surface-border p-8 text-center text-ink2 text-sm">
              Nothing queued. Add a niche above or schedule a video from the Videos tab.
            </div>
          )}
        </section>
      </div>
    </>
  );
}
