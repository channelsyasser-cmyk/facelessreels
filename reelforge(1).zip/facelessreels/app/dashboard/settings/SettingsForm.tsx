"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import type { Profile } from "@/lib/types";

const TIMEZONES = [
  "UTC",
  "America/New_York",
  "America/Los_Angeles",
  "America/Chicago",
  "Europe/London",
  "Europe/Berlin",
  "Asia/Singapore",
  "Asia/Tokyo",
  "Australia/Sydney",
];

export function SettingsForm({ profile }: { profile: Profile | null }) {
  const supabase = createClient();
  const [timezone, setTimezone] = useState(profile?.timezone ?? "UTC");
  const [saved, setSaved] = useState(false);

  async function handleSave() {
    if (!profile) return;
    await supabase.from("profiles").update({ timezone }).eq("id", profile.id);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  return (
    <div className="rounded-xl2 border border-surface-border bg-surface p-6">
      <label className="text-xs text-ink2 mb-1.5 block">Timezone</label>
      <p className="text-xs text-ink2 mb-3">
        Used to interpret each niche's posting time when the daily scheduler runs.
      </p>
      <select
        value={timezone}
        onChange={(e) => setTimezone(e.target.value)}
        className="w-full rounded-lg bg-ink-800 border border-surface-border px-3 py-2.5 text-sm outline-none focus:border-ember transition mb-4"
      >
        {TIMEZONES.map((tz) => (
          <option key={tz} value={tz}>
            {tz}
          </option>
        ))}
      </select>
      <button
        onClick={handleSave}
        className="rounded-full bg-ember text-ink-900 font-medium px-4 py-2 text-sm hover:bg-ember-soft transition"
      >
        {saved ? "Saved" : "Save changes"}
      </button>
    </div>
  );
}
