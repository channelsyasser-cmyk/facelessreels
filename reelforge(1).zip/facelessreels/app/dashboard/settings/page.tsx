import { createServerSupabase } from "@/lib/supabase/server";
import { TopBar } from "@/components/TopBar";
import { SettingsForm } from "./SettingsForm";

export default async function SettingsPage() {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user?.id)
    .single();

  return (
    <>
      <TopBar title="Settings" />
      <div className="p-8 max-w-md">
        <SettingsForm profile={profile} />
      </div>
    </>
  );
}
