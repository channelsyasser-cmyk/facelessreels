import { createServerSupabase } from "@/lib/supabase/server";
import { TopBar } from "@/components/TopBar";
import { VideoCard } from "@/components/VideoCard";
import type { VideoRecord } from "@/lib/types";

export default async function VideosPage() {
  const supabase = createServerSupabase();
  const { data: videos } = await supabase
    .from("videos")
    .select("*")
    .order("created_at", { ascending: false });

  return (
    <>
      <TopBar title="Videos" />
      <div className="p-8 max-w-4xl">
        {videos && videos.length > 0 ? (
          <div className="flex flex-col gap-3">
            {(videos as VideoRecord[]).map((v) => (
              <VideoCard key={v.id} video={v} />
            ))}
          </div>
        ) : (
          <div className="rounded-xl2 border border-dashed border-surface-border p-10 text-center text-ink2 text-sm">
            No videos yet — head to Create to generate your first one.
          </div>
        )}
      </div>
    </>
  );
}
